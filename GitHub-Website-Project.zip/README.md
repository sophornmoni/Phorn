# My GitHub Pages Website

## Upload to GitHub
1. Create a new GitHub repository (for example `my-website`).
2. Upload `index.html`, `style.css`, `script.js`, `assets/`, and `README.md`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then **Save**.
6. After deployment, open the Pages URL shown by GitHub.

## Edit
- Main content: `index.html`
- Design: `style.css`
- Dark mode/menu: `script.js`
- Images/files: `assets/`

No build step is required.
